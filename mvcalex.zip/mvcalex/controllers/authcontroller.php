<?php
// controllers/AuthController.php
require_once 'models/UserModel.php';
require_once 'models/OTPModel.php';
require_once 'models/AuditModel.php';

class AuthController
{
    private $audit;

    public function __construct()
    {
        $this->audit = new AuditModel();
    }

    public function showLogin()
    {
        require_once 'views/login.php';
    }

    public function showRegister()
    {
        require_once 'views/register.php';
    }

    public function do_register()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'];
            $email = $_POST['email'];

            $userModel = new UserModel();
            $otpModel = new OTPModel();

            // 1. Guardar usuario en JSON
            $userModel->create($email, $name);

            // 2. Generar código OTP
            $code = $otpModel->generate($email);

            // 3. Auditoría (Fase 6)
            $this->audit->log('EVENT_REGISTER', $email, "Usuario: $name");
            $this->audit->log('EVENT_OTP_SENT', $email, "Código generado");

            $_SESSION['temp_email'] = $email;

            // Redirigir a pantalla de verificación
            header("Location: index.php?action=verify");
            exit();
        }
    }

    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'];
            $userModel = new UserModel();

            $user = $userModel->findByEmail($email);

            if ($user) {
                // Generar OTP
                $otpModel = new OTPModel();
                $code = $otpModel->generate($email);

                // Auditoría
                $this->audit->log('EVENT_LOGIN_ATTEMPT', $email, "Intento de login");
                $this->audit->log('EVENT_OTP_SENT', $email, "Código enviado para login");

                $_SESSION['temp_email'] = $email;
                header("Location: index.php?action=verify");
                exit();
            }
            else {
                // Usuario no encontrado
                $this->audit->log('EVENT_LOGIN_FAIL', $email, "Usuario no encontrado");
                header("Location: index.php?action=login&error=user_not_found");
                exit();
            }
        }
    }

    public function do_verify()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $code = $_POST['code'];
            $email = $_SESSION['temp_email'] ?? null;

            if ($email) {
                $otpModel = new OTPModel();
                if ($otpModel->verify($email, $code)) {
                    // Login exitoso
                    $userModel = new UserModel();
                    $user = $userModel->findByEmail($email);

                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    unset($_SESSION['temp_email']);

                    $this->audit->log('EVENT_LOGIN_SUCCESS', $email, "Login exitoso");

                    header("Location: index.php?action=dashboard");
                    exit();
                }
                else {
                    $this->audit->log('EVENT_VERIFY_FAIL', $email, "Código inválido");
                    header("Location: index.php?action=verify&error=invalid_code");
                    exit();
                }
            }
            else {
                header("Location: index.php?action=login");
                exit();
            }
        }
    }

    public function showDashboard()
    {
        if (!isLoggedIn()) {
            redirect('index.php?action=login');
        }
        require_once 'views/dashboard.php';
    }

    public function logout()
    {
        $email = $_SESSION['user_name'] ?? 'Unknown'; // O user_id, o lo que guardemos
        // En un caso real, mejor obtener el email de la sesión si lo guardamos, o del ID.
        // Por simplicidad, registramos el logout.
        $this->audit->log('EVENT_LOGOUT', $email, "Cierre de sesión");

        session_destroy();
        redirect('index.php?action=login');
    }
}