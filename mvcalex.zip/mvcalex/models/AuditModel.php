<?php
// models/AuditModel.php
class AuditModel {
    private $file = 'data/audit.json';

    public function log($event, $email, $details = "") {
        // Leer datos actuales
        $logs = file_exists($this->file) ? json_decode(file_get_contents($this->file), true) : [];

        // Preparar el nuevo registro [cite: 141, 143, 144, 145, 146]
        $newLog = [
            'event' => $event,
            'email' => $email,
            'ip' => $_SERVER['REMOTE_ADDR'], // Captura la IP [cite: 144]
            'date' => date('Y-m-d H:i:s'),    // Captura la fecha [cite: 145]
            'user_agent' => $_SERVER['HTTP_USER_AGENT'], // Navegador [cite: 146]
            'details' => $details
        ];

        $logs[] = $newLog;
        return file_put_contents($this->file, json_encode($logs, JSON_PRETTY_PRINT));
    }

    public function getAll() {
        return file_exists($this->file) ? json_decode(file_get_contents($this->file), true) : [];
    }
}
?>