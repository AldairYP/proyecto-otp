<?php
// models/UserModel.php
class UserModel {
    private $file = 'data/users.json';

    public function findByEmail($email) {
        $users = json_decode(file_get_contents($this->file), true) ?: []; // [cite: 54]
        foreach ($users as $user) {
            if ($user['email'] === $email) return $user; // [cite: 55]
        }
        return null;
    }

    public function create($email, $name) {
        $users = json_decode(file_get_contents($this->file), true) ?: [];
        $newUser = [
            'id' => uniqid(),
            'email' => $email, // [cite: 56]
            'name' => $name,   // [cite: 56]
            'created_at' => date('Y-m-d H:i:s')
        ];
        $users[] = $newUser;
        return file_put_contents($this->file, json_encode($users)); // [cite: 70]
    }
}
?>