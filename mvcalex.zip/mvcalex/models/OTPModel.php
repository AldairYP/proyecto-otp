<?php
// models/OTPModel.php
class OTPModel
{
    private $file = 'data/otp.json';

    public function generate($email)
    {
        $code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT); // Código de 6 dígitos [cite: 61]
        $expiration = date('Y-m-d H:i:s', strtotime('+5 minutes')); // [cite: 62]

        $otps = json_decode(file_get_contents($this->file), true) ?: [];
        $otps[$email] = ['code' => $code, 'expires' => $expiration];

        file_put_contents($this->file, json_encode($otps));
        return $code;
    }

    public function verify($email, $code)
    {
        $otps = json_decode(file_get_contents($this->file), true) ?: [];

        if (!isset($otps[$email])) {
            return false;
        }

        $record = $otps[$email];

        // Verificar código y expiración
        if ($record['code'] === $code && strtotime($record['expires']) > time()) {
            // Opcional: Eliminar OTP después de uso exitoso
            // unset($otps[$email]);
            // file_put_contents($this->file, json_encode($otps));
            return true;
        }

        return false;
    }
}
?>