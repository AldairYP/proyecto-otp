<?php
$auditModel = new AuditModel();
$logs = array_reverse($auditModel->getAll()); // Mostrar los más recientes primero
?>

<h2>Registro de Auditoría</h2>
<table border="1" cellpadding="10" style="width:100%; border-collapse: collapse;">
    <thead>
        <tr>
            <th>Fecha</th>
            <th>Evento</th>
            <th>Email</th>
            <th>IP</th>
            <th>Detalles</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($logs as $log): ?>
        <tr>
            <td><?php echo $log['date']; ?></td>
            <td><strong><?php echo $log['event']; ?></strong></td>
            <td><?php echo $log['email']; ?></td>
            <td><?php echo $log['ip']; ?></td>
            <td><?php echo $log['details']; ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<p><a href="index.php?action=dashboard">Volver al Dashboard</a></p>