<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <h2>Bienvenido, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h2>
    <p>Has iniciado sesion exitosamente.</p>
    
    <ul>
        <li><a href="index.php?action=audit">Ver Auditoria</a></li>
        <li><a href="index.php?action=logout">Cerrar Sesion</a></li>
    </ul>
</body>
</html>
