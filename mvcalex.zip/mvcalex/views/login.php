<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <?php if (isset($_GET['error'])): ?>
        <p style="color:red;">Error: <?php echo htmlspecialchars($_GET['error']); ?></p>
    <?php
endif; ?>
    <form action="index.php?action=do_login" method="POST">
        <label>Email:</label>
        <input type="email" name="email" required>
        <button type="submit">Login</button>
    </form>
    <p>No tienes cuenta? <a href="index.php?action=register">Registrate aqui</a></p>
</body>
</html>
