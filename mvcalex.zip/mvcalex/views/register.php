<!DOCTYPE html>
<html>
<head>
    <title>Registro</title>
</head>
<body>
    <h2>Registro</h2>
    <form action="index.php?action=do_register" method="POST">
        <label>Nombre:</label>
        <input type="text" name="name" required><br>
        <label>Email:</label>
        <input type="email" name="email" required><br>
        <button type="submit">Registrar</button>
    </form>
    <p>Ya tienes cuenta? <a href="index.php?action=login">Inicia sesion</a></p>
</body>
</html>
