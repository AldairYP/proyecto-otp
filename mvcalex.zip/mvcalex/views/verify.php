<!DOCTYPE html>
<html>
<head>
    <title>Verificar OTP</title>
</head>
<body>
    <h2>Verificar OTP</h2>
    <p>Se ha enviado un codigo a tu correo.</p>
    <?php if (isset($_GET['error'])): ?>
        <p style="color:red;">Error: <?php echo htmlspecialchars($_GET['error']); ?></p>
    <?php
endif; ?>
    <form action="index.php?action=do_verify" method="POST">
        <label>Codigo OTP:</label>
        <input type="text" name="code" required>
        <button type="submit">Verificar</button>
    </form>
</body>
</html>
